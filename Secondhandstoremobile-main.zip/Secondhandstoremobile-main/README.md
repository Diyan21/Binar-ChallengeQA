This is our repository for Platinum Challenge Quality Assurance Bootcamp Binar Academy 

Our Team:
1. Fadhilah Alwi
2. Yoshua Senna Januar
3. Muhammad Ageng
4. Riswanda Al Farisi
5. Faridatul Asriyyah
6. Aliffrizia Vahy Holifa Sahita
7. Aufar Luthfi Rahman
8. Asadul Haq Ali Hamidi
